'use strict';
const fs = require('fs');
const path = require('path');
const { validateBundleName } = require('./project');

const xmlEscape = (s) =>
  String(s).replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' })[c]);

function writeIfMissing(file, content, created) {
  if (fs.existsSync(file)) return;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content);
  created.push(file);
}

/**
 * Create the metadata a new UI Bundle needs (existing files are left alone):
 *   uiBundles/<name>/ui-bundle.json and <name>.uibundle-meta.xml
 *   applications/<name>.app-meta.xml       (Custom Application that opens the bundle)
 *   permissionsets/<name>_Access.permissionset-meta.xml (makes the app visible)
 * Returns the files created and the folders to deploy.
 */
function scaffoldBundle(project, name, { label = name, description = 'WaveMaker React app deployed as a Salesforce UI Bundle.' } = {}) {
  validateBundleName(name);
  const base = path.join(project.packageDir, 'main', 'default');
  const ns = project.namespace || 'c';
  const created = [];

  const bundleDir = path.join(base, 'uiBundles', name);
  writeIfMissing(
    path.join(bundleDir, 'ui-bundle.json'),
    JSON.stringify({ outputDir: 'dist', routing: { trailingSlash: 'never', fallback: 'index.html' } }, null, 2) + '\n',
    created
  );
  writeIfMissing(
    path.join(bundleDir, `${name}.uibundle-meta.xml`),
    `<?xml version="1.0" encoding="UTF-8"?>
<UIBundle xmlns="http://soap.sforce.com/2006/04/metadata">
    <masterLabel>${xmlEscape(label)}</masterLabel>
    <description>${xmlEscape(description)}</description>
    <isActive>true</isActive>
    <version>1</version>
    <target>CustomApplication</target>
</UIBundle>
`,
    created
  );

  const appFile = path.join(base, 'applications', `${name}.app-meta.xml`);
  writeIfMissing(
    appFile,
    `<?xml version="1.0" encoding="UTF-8"?>
<CustomApplication xmlns="http://soap.sforce.com/2006/04/metadata">
    <brand>
        <headerColor>#0070D2</headerColor>
        <shouldOverrideOrgTheme>false</shouldOverrideOrgTheme>
    </brand>
    <formFactors>Small</formFactors>
    <formFactors>Large</formFactors>
    <isNavAutoTempTabsDisabled>false</isNavAutoTempTabsDisabled>
    <isNavPersonalizationDisabled>false</isNavPersonalizationDisabled>
    <isNavTabPersistenceDisabled>false</isNavTabPersistenceDisabled>
    <isOmniPinnedViewEnabled>false</isOmniPinnedViewEnabled>
    <label>${xmlEscape(label)}</label>
    <navType>Standard</navType>
    <uiBundle>${ns}__${name}</uiBundle>
    <uiType>Lightning</uiType>
</CustomApplication>
`,
    created
  );

  const permsetName = `${name}_Access`;
  const permsetFile = path.join(base, 'permissionsets', `${permsetName}.permissionset-meta.xml`);
  writeIfMissing(
    permsetFile,
    `<?xml version="1.0" encoding="UTF-8"?>
<PermissionSet xmlns="http://soap.sforce.com/2006/04/metadata">
    <applicationVisibilities>
        <application>${name}</application>
        <visible>true</visible>
    </applicationVisibilities>
    <hasActivationRequired>false</hasActivationRequired>
    <label>${xmlEscape(label)} Access</label>
</PermissionSet>
`,
    created
  );

  return { created, bundleDir, appFile, permsetFile, permsetName };
}

module.exports = { scaffoldBundle };
