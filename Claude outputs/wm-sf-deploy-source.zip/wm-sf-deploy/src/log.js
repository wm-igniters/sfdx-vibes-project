'use strict';

const color = (code) => (s) => (process.stdout.isTTY && !process.env.NO_COLOR ? `\x1b[${code}m${s}\x1b[0m` : s);
const bold = color('1');
const dim = color('2');
const green = color('32');
const yellow = color('33');
const red = color('31');
const cyan = color('36');

let stepNo = 0;

module.exports = {
  bold,
  dim,
  green,
  yellow,
  red,
  cyan,
  step(title) {
    stepNo += 1;
    console.log(`\n${cyan(bold(`[${stepNo}]`))} ${bold(title)}`);
  },
  info(msg) {
    console.log(`    ${msg}`);
  },
  ok(msg) {
    console.log(`    ${green('✔')} ${msg}`);
  },
  warn(msg) {
    console.warn(`    ${yellow('!')} ${msg}`);
  },
  error(msg) {
    console.error(`${red('✖')} ${msg}`);
  },
  resetSteps() {
    stepNo = 0;
  }
};
