'use strict';
const path = require('path');
const { run } = require('./run');

/** sf project deploy start for the bundle (plus any extra metadata), from the project root. */
async function deploy({ projectRoot, sourceDirs, targetOrg, wait, extraArgs = [] }) {
  const args = ['project', 'deploy', 'start'];
  for (const dir of sourceDirs) args.push('--source-dir', path.relative(projectRoot, dir) || '.');
  if (targetOrg) args.push('--target-org', targetOrg);
  if (wait) args.push('--wait', String(wait));
  args.push(...extraArgs);
  await run('sf', args, { cwd: projectRoot });
  return ['sf', ...args].join(' ');
}

/** Assign a permission set (an existing assignment is reported as success). */
async function assignPermset({ projectRoot, permsetName, targetOrg }) {
  const args = ['org', 'assign', 'permset', '--name', permsetName, '--json'];
  if (targetOrg) args.push('--target-org', targetOrg);
  try {
    await run('sf', args, { cwd: projectRoot, capture: true, quiet: true });
    return 'assigned';
  } catch (err) {
    if (/Duplicate PermissionSetAssignment/i.test(err.output || '')) return 'already assigned';
    throw err;
  }
}

/** The org's instance URL from `sf org display`, or null. */
async function orgInstanceUrl({ projectRoot, targetOrg }) {
  const args = ['org', 'display', '--json'];
  if (targetOrg) args.push('--target-org', targetOrg);
  try {
    const out = await run('sf', args, { cwd: projectRoot, capture: true, quiet: true });
    return JSON.parse(out)?.result?.instanceUrl ?? null;
  } catch {
    return null;
  }
}

/**
 * UI Bundle URL from the org's My Domain:
 *   https://acme.my.salesforce.com                → https://acme--c.my.salesforce.app/app/c__<bundle>
 *   https://acme-dev-ed.develop.my.salesforce.com → https://acme-dev-ed--c.develop.my.salesforce.app/app/c__<bundle>
 */
function bundleUrl(instanceUrl, bundleName, namespace = 'c') {
  let host;
  try {
    host = new URL(instanceUrl).hostname;
  } catch {
    return null;
  }
  const m = /^([a-z0-9-]+)((?:\.[a-z0-9-]+)*)\.my\.salesforce\.com$/i.exec(host);
  if (!m) return null;
  const [, myDomain, instance] = m;
  return `https://${myDomain}--${namespace}${instance}.my.salesforce.app/app/${namespace}__${bundleName}`;
}

module.exports = { deploy, assignPermset, orgInstanceUrl, bundleUrl };
