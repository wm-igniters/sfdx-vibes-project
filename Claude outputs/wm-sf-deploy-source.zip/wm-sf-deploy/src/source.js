'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const AdmZip = require('adm-zip');

/**
 * Prepare the WaveMaker React app in `workDir/app`:
 *  - a .zip is extracted there (a single top-level folder in the zip is unwrapped);
 *  - a folder is copied there (never built in place, so the original stays untouched).
 * node_modules from the previous run is kept, so unchanged dependencies are not reinstalled.
 * Returns the app folder.
 */
function prepareSource(source, workDir) {
  const src = path.resolve(source);
  if (!fs.existsSync(src)) throw new Error(`Source not found: ${src}`);

  const appDir = path.join(workDir, 'app');
  const keptModules = path.join(workDir, '.node_modules');
  fs.mkdirSync(workDir, { recursive: true });

  // Keep node_modules aside while the app folder is replaced.
  fs.rmSync(keptModules, { recursive: true, force: true });
  if (fs.existsSync(path.join(appDir, 'node_modules'))) {
    fs.renameSync(path.join(appDir, 'node_modules'), keptModules);
  }
  fs.rmSync(appDir, { recursive: true, force: true });

  if (fs.statSync(src).isDirectory()) {
    fs.cpSync(src, appDir, {
      recursive: true,
      filter: (p) => !/[\\/](node_modules|\.next|build)$/.test(p) || path.dirname(p) !== src
    });
  } else if (/\.zip$/i.test(src)) {
    const staging = path.join(workDir, '.unzip');
    fs.rmSync(staging, { recursive: true, force: true });
    new AdmZip(src).extractAllTo(staging, true);
    fs.renameSync(findAppRoot(staging), appDir);
    fs.rmSync(staging, { recursive: true, force: true });
  } else {
    throw new Error(`Source must be a WaveMaker React .zip or an extracted folder: ${src}`);
  }

  if (!fs.existsSync(path.join(appDir, 'package.json'))) {
    throw new Error(`No package.json in the WaveMaker export (${src}). Is this the React code zip?`);
  }
  if (fs.existsSync(keptModules)) fs.renameSync(keptModules, path.join(appDir, 'node_modules'));
  return appDir;
}

/** The folder holding package.json: the extraction root or its single top-level folder. */
function findAppRoot(dir) {
  if (fs.existsSync(path.join(dir, 'package.json'))) return dir;
  const entries = fs.readdirSync(dir, { withFileTypes: true }).filter((e) => !e.name.startsWith('__MACOSX'));
  const dirs = entries.filter((e) => e.isDirectory());
  if (dirs.length === 1 && entries.length === 1) return findAppRoot(path.join(dir, dirs[0].name));
  throw new Error('Could not find package.json in the zip.');
}

/** Hash of the dependency manifest, to skip `npm install` when nothing changed. */
function dependencyHash(appDir) {
  const hash = crypto.createHash('sha256');
  for (const f of ['package.json', 'package-lock.json', '.npmrc']) {
    const file = path.join(appDir, f);
    if (fs.existsSync(file)) hash.update(f).update(fs.readFileSync(file));
  }
  return hash.digest('hex');
}

module.exports = { prepareSource, findAppRoot, dependencyHash };
