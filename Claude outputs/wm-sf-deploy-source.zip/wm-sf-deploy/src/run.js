'use strict';
const { spawn } = require('child_process');

const isWindows = process.platform === 'win32';

class CommandError extends Error {
  constructor(command, code, output) {
    super(`Command failed (exit ${code}): ${command}`);
    this.code = code;
    this.output = output;
  }
}

/**
 * Run a command, streaming its output to the terminal.
 * `capture: true` returns stdout instead of streaming it (stderr still streams).
 * On Windows npm/npx/sf are .cmd shims, so they need a shell.
 */
function run(cmd, args, { cwd, env, capture = false, quiet = false } = {}) {
  const pretty = [cmd, ...args].join(' ');
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd,
      env: { ...process.env, ...env },
      shell: isWindows,
      stdio: capture ? ['inherit', 'pipe', quiet ? 'pipe' : 'inherit'] : quiet ? 'ignore' : 'inherit'
    });
    let out = '';
    if (capture) child.stdout.on('data', (d) => (out += d));
    child.on('error', (err) => {
      if (err.code === 'ENOENT') reject(new Error(`"${cmd}" was not found on your PATH.`));
      else reject(err);
    });
    child.on('close', (code) => (code === 0 ? resolve(out) : reject(new CommandError(pretty, code, out))));
  });
}

/** True when `cmd --version` runs. */
async function hasCommand(cmd) {
  try {
    await run(cmd, ['--version'], { capture: true, quiet: true });
    return true;
  } catch {
    return false;
  }
}

/** Split a command line like "npx next build" into [cmd, args]. Quotes are respected. */
function splitCommand(line) {
  const parts = line.match(/"[^"]*"|'[^']*'|\S+/g) || [];
  const clean = parts.map((p) => p.replace(/^["']|["']$/g, ''));
  return [clean[0], clean.slice(1)];
}

module.exports = { run, hasCommand, splitCommand, CommandError };
