'use strict';
// Programmatic API (the CLI is bin/wm-sf.js).
module.exports = {
  ...require('./build'),
  ...require('./project'),
  ...require('./source'),
  ...require('./scaffold'),
  ...require('./deploy'),
  main: require('./cli').main
};
