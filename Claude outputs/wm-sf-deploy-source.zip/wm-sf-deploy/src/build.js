'use strict';
/**
 * Builds a WaveMaker React (Next.js) export as a Salesforce UI Bundle.
 *
 * Salesforce UI Bundle hosting differs from a plain static host in ways a Next.js export trips over:
 *  - The app lives under a sub-path, so Next's basePath and the WaveMaker server path must be baked in.
 *  - CSP allows only 'self' + nonce scripts, so Next's inline flight scripts must be externalized.
 *  - Every route (any .html or extension-less path) is answered with index.html.
 *  - .txt files are served as text/html with an injected <head>, which corrupts Next's RSC payloads.
 *  - Every file is served with `cache-control: max-age=31536000, immutable`, so a non-hashed URL
 *    (RSC payloads, servicedefs.json, wmProperties.js, sf-shim.js) keeps returning the previous
 *    deployment's copy. A stale RSC payload carries the old build id and makes Next reload the page
 *    in a loop, so those URLs get a ?v=<buildId> cache-buster.
 * The last three are handled by sf-shim.js (injected first into every page) plus .txt.json copies.
 */
const fs = require('fs');
const path = require('path');
const { run, splitCommand } = require('./run');
const log = require('./log');

const walk = (dir) =>
  fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const abs = path.join(dir, e.name);
    return e.isDirectory() ? walk(abs) : [abs];
  });

/** Run the Next.js static export with the Salesforce base path baked in. */
async function nextBuild(appDir, basePath, buildCommand = 'npx next build') {
  const [cmd, args] = splitCommand(buildCommand);
  await run(cmd, args, {
    cwd: appDir,
    env: { NEXT_PUBLIC_BASE_PATH: basePath, NEXT_PUBLIC_SERVER_PATH: basePath }
  });
  const buildDir = path.join(appDir, 'build');
  if (!fs.existsSync(buildDir)) {
    throw new Error(`The build did not produce ${buildDir}. Is this a WaveMaker React (Next.js) export?`);
  }
  return buildDir;
}

/** Move Next inline scripts to external files (WaveMaker's own CSP step). */
function externalizeInlineScripts(appDir, buildDir) {
  const modulePath = path.join(appDir, 'node_modules', '@wavemaker-ai', 'react-codegen', 'src', 'externalize-next-scripts.js');
  if (!fs.existsSync(modulePath)) {
    throw new Error(
      `${modulePath} not found. It comes with the WaveMaker export's dependencies; ` +
        'run without --skip-install, or pass --skip-externalize if your export already handles CSP.'
    );
  }
  const { externalizeNextInlineScripts } = require(modulePath);
  return externalizeNextInlineScripts(buildDir);
}

/** Serve RSC payloads as .json, which Salesforce returns untouched. */
function copyRscPayloads(buildDir) {
  const txtFiles = walk(buildDir).filter((f) => f.endsWith('.txt'));
  txtFiles.forEach((f) => fs.copyFileSync(f, `${f}.json`));
  return txtFiles.length;
}

/** The shim. It must run before Next's chunks, so it goes first in <head> as a blocking script. */
function shimSource(buildId) {
  return `(function () {
  var base = new URL(document.currentScript.src).pathname.replace(/\\/sf-shim\\.js$/, '');
  var sameApp = function (u) { return u.origin === location.origin && u.pathname.indexOf(base + '/') === 0; };

  // Salesforce caches every file for a year; tag non-hashed app files with this build's id.
  var version = function (u) {
    if (sameApp(u) && u.pathname.indexOf(base + '/_next/static/') !== 0) u.searchParams.set('v', ${JSON.stringify(buildId)});
    return u;
  };

  // Salesforce answers every route with index.html (the "/" tree). Hydrating it under another path
  // renders nothing, so reset deep links to the root; the app then redirects to its home page.
  if (location.pathname !== base && location.pathname !== base + '/') {
    history.replaceState(history.state, '', base + location.search + location.hash);
  }

  // Next fetches RSC payloads as <route>.txt; read the .txt.json copy and restore the content type.
  var origFetch = window.fetch;
  window.fetch = function (input, init) {
    var raw = typeof input === 'string' || input instanceof URL ? String(input) : input.url;
    var url = new URL(raw, location.href);
    if (sameApp(url) && /\\.txt$/.test(url.pathname)) {
      var original = url.href;
      url.pathname += '.json';
      return origFetch.call(this, version(url).href, init).then(function (res) {
        var out = new Response(res.body, {
          status: res.status,
          statusText: res.statusText,
          headers: { 'content-type': 'text/x-component' },
        });
        Object.defineProperty(out, 'url', { value: original });
        return out;
      });
    }
    if (sameApp(url) && typeof input === 'string') arguments[0] = version(url).href;
    return origFetch.apply(this, arguments);
  };

  // With a server path set, the runtime asks for the backend endpoint services/servicedefs;
  // point it at the static JSON instead.
  var origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    var u = new URL(url, location.href);
    if (sameApp(u) && u.pathname === base + '/services/servicedefs') {
      u.pathname += '.json';
    }
    if (sameApp(u)) arguments[1] = version(u).href;
    return origOpen.apply(this, arguments);
  };
})();
`;
}

/** Write sf-shim.js and load it first in every page. Returns the number of pages tagged. */
function injectShim(buildDir, basePath, buildId) {
  fs.writeFileSync(path.join(buildDir, 'sf-shim.js'), shimSource(buildId));
  const shimTag = `<script src="${basePath}/sf-shim.js?v=${buildId}"></script>`;
  let tagged = 0;
  walk(buildDir)
    .filter((f) => f.endsWith('.html'))
    .forEach((f) => {
      const html = fs.readFileSync(f, 'utf8');
      if (!html.includes('/sf-shim.js')) {
        fs.writeFileSync(f, html.replace('<head>', `<head>${shimTag}`));
        tagged += 1;
      }
    });
  return tagged;
}

/** Replace the bundle's output folder with the build. */
function copyToBundle(buildDir, outDir) {
  fs.rmSync(outDir, { recursive: true, force: true });
  fs.cpSync(buildDir, outDir, { recursive: true });
}

/** Full build: Next export → CSP → RSC copies → shim → copy into the bundle's output folder. */
async function buildBundle({ appDir, outDir, basePath, buildCommand, skipExternalize = false }) {
  log.info(`Next.js build with basePath ${log.bold(basePath)}`);
  const buildDir = await nextBuild(appDir, basePath, buildCommand);

  if (skipExternalize) {
    log.warn('Skipped externalizing inline scripts (--skip-externalize).');
  } else {
    const result = externalizeInlineScripts(appDir, buildDir);
    log.ok(`Externalized inline scripts${result !== undefined ? `: ${JSON.stringify(result)}` : ''}`);
  }

  log.ok(`Copied ${copyRscPayloads(buildDir)} RSC payloads to .txt.json`);

  const buildIdFile = path.join(appDir, '.next', 'BUILD_ID');
  if (!fs.existsSync(buildIdFile)) throw new Error(`${buildIdFile} not found after the build.`);
  const buildId = fs.readFileSync(buildIdFile, 'utf8').trim();
  log.ok(`Injected sf-shim.js (build ${buildId}) into ${injectShim(buildDir, basePath, buildId)} page(s)`);

  copyToBundle(buildDir, outDir);
  log.ok(`Copied build to ${outDir}`);
  return { buildId, buildDir };
}

module.exports = { buildBundle, nextBuild, externalizeInlineScripts, copyRscPayloads, injectShim, shimSource, copyToBundle, walk };
