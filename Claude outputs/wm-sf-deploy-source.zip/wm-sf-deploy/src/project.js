'use strict';
const fs = require('fs');
const path = require('path');

const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

/** Walk up from `start` to the folder holding sfdx-project.json. */
function findProjectRoot(start) {
  let dir = path.resolve(start);
  for (;;) {
    if (fs.existsSync(path.join(dir, 'sfdx-project.json'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

/** Load an SFDX project: root, default package directory, uiBundles folder, default org. */
function loadProject(start) {
  const root = findProjectRoot(start);
  if (!root) {
    throw new Error(`No Salesforce DX project found at or above ${path.resolve(start)} (missing sfdx-project.json).`);
  }
  const config = readJson(path.join(root, 'sfdx-project.json'));
  const pkgDirs = config.packageDirectories || [];
  const pkg = pkgDirs.find((p) => p.default) || pkgDirs[0];
  if (!pkg) throw new Error(`sfdx-project.json in ${root} has no packageDirectories.`);
  const packageDir = path.join(root, pkg.path);
  const uiBundlesDir = path.join(packageDir, 'main', 'default', 'uiBundles');
  return {
    root,
    name: config.name,
    namespace: config.namespace || '',
    apiVersion: config.sourceApiVersion,
    packageDir,
    uiBundlesDir,
    defaultOrg: readDefaultOrg(root)
  };
}

/** The project's default org alias (sf config set target-org …), if any. */
function readDefaultOrg(root) {
  const candidates = [
    [path.join(root, '.sf', 'config.json'), 'target-org'],
    [path.join(root, '.sfdx', 'sfdx-config.json'), 'defaultusername']
  ];
  for (const [file, key] of candidates) {
    try {
      const value = readJson(file)[key];
      if (value) return value;
    } catch {
      /* not set */
    }
  }
  return null;
}

/** UI Bundle folders (those with ui-bundle.json) under the project's uiBundles folder. */
function listBundles(project) {
  if (!fs.existsSync(project.uiBundlesDir)) return [];
  return fs
    .readdirSync(project.uiBundlesDir, { withFileTypes: true })
    .filter((e) => e.isDirectory() && fs.existsSync(path.join(project.uiBundlesDir, e.name, 'ui-bundle.json')))
    .map((e) => e.name)
    .sort();
}

const BUNDLE_NAME = /^[A-Za-z][A-Za-z0-9_]*$/;

function validateBundleName(name) {
  if (!BUNDLE_NAME.test(name || '')) {
    throw new Error(
      `"${name}" is not a valid UI Bundle name: use letters, digits and underscores, starting with a letter.`
    );
  }
  return name;
}

/** Resolve the bundle folder: an explicit path, or a name under the project's uiBundles folder. */
function resolveBundleDir(project, bundle) {
  if (bundle.includes('/') || bundle.includes('\\')) return path.resolve(bundle);
  return path.join(project.uiBundlesDir, validateBundleName(bundle));
}

/** The bundle's output folder (ui-bundle.json "outputDir", default dist). */
function bundleOutputDir(bundleDir) {
  const config = readJson(path.join(bundleDir, 'ui-bundle.json'));
  return path.join(bundleDir, config.outputDir || 'dist');
}

module.exports = {
  findProjectRoot,
  loadProject,
  readDefaultOrg,
  listBundles,
  validateBundleName,
  resolveBundleDir,
  bundleOutputDir
};
