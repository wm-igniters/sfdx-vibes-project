'use strict';
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { parseArgs } = require('util');

const log = require('./log');
const { run, hasCommand } = require('./run');
const { loadProject, listBundles, resolveBundleDir, bundleOutputDir, validateBundleName } = require('./project');
const { prepareSource, dependencyHash } = require('./source');
const { buildBundle } = require('./build');
const { scaffoldBundle } = require('./scaffold');
const { deploy, assignPermset, orgInstanceUrl, bundleUrl } = require('./deploy');
const pkg = require('../package.json');

const HELP = `
${log.bold('wm-sf')} — build a WaveMaker React export as a Salesforce UI Bundle and deploy it

${log.bold('Usage')}
  wm-sf deploy [source] [options]   Build and deploy (default command)
  wm-sf build  [source] [options]   Build into the SFDX project only, no deploy
  wm-sf init   <bundle> [options]   Create a new UI Bundle + app + permission set in the project

${log.bold('Inputs')}
  [source], -s, --source <path>     WaveMaker React code .zip (from Studio) or its extracted folder
  -p, --project <dir>               Salesforce DX project (folder with sfdx-project.json)   [default: current folder]
  -b, --bundle <name|path>          UI Bundle (Multi-Framework app) to fill, e.g. employeeapp
                                    [default: the only bundle under <package>/main/default/uiBundles]
  -o, --target-org <alias>          Org alias or username                                  [default: the project's target-org]

${log.bold('Options')}
  --base-path <path>                URL base path baked into the build                     [default: /app/c__<bundle>]
  --work-dir <dir>                  Where the export is unpacked and built                 [default: <project>/.wm-sf/<bundle>]
  --build-command <cmd>             Next.js build command                                  [default: "npx next build"]
  --skip-install                    Don't run npm install (reuse the work dir's node_modules)
  --npm-verbose                     npm install --verbose
  --skip-externalize                Skip moving Next's inline scripts out (CSP); only if your export does it
  --create                          Create the bundle, app and permission set if the bundle doesn't exist
  --with-app                        Also deploy the bundle's Custom Application and permission set
  --assign-permset                  Assign <bundle>_Access to the deploying user after the deploy
  --deploy-dir <path>               Extra metadata to deploy with the bundle (repeatable)
  --wait <minutes>                  Passed to sf project deploy start --wait
  --dry-run                         Show the plan and stop
  -y, --yes                         Don't ask for confirmation
  -h, --help                        Show this help
  -v, --version                     Show the version

${log.bold('Examples')}
  wm-sf deploy ~/Downloads/employeeapp.zip -p ~/Documents/WM-SF/my-sfdx-vibes-project -b employeeapp -o Wavemaker
  cd my-sfdx-vibes-project && wm-sf deploy ~/Downloads/employeeapp.zip
  wm-sf init illustrationapp -p ./my-sfdx-vibes-project
`;

const OPTIONS = {
  source: { type: 'string', short: 's' },
  project: { type: 'string', short: 'p' },
  bundle: { type: 'string', short: 'b' },
  'target-org': { type: 'string', short: 'o' },
  'base-path': { type: 'string' },
  'work-dir': { type: 'string' },
  'build-command': { type: 'string' },
  'skip-install': { type: 'boolean' },
  'npm-verbose': { type: 'boolean' },
  'skip-externalize': { type: 'boolean' },
  create: { type: 'boolean' },
  'with-app': { type: 'boolean' },
  'assign-permset': { type: 'boolean' },
  'deploy-dir': { type: 'string', multiple: true },
  wait: { type: 'string' },
  label: { type: 'string' },
  'dry-run': { type: 'boolean' },
  yes: { type: 'boolean', short: 'y' },
  help: { type: 'boolean', short: 'h' },
  version: { type: 'boolean', short: 'v' }
};

const interactive = () => process.stdin.isTTY && process.stdout.isTTY && !process.env.CI;

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) =>
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim());
    })
  );
}

const expandHome = (p) => (p && p.startsWith('~') ? path.join(require('os').homedir(), p.slice(1)) : p);

async function chooseBundle(project, given) {
  if (given) return given;
  const bundles = listBundles(project);
  if (bundles.length === 1) return bundles[0];
  if (!interactive()) {
    throw new Error(
      bundles.length
        ? `Several UI Bundles found (${bundles.join(', ')}); pass --bundle <name>.`
        : `No UI Bundle in ${project.uiBundlesDir}; pass --bundle <name> --create, or run "wm-sf init <name>".`
    );
  }
  if (bundles.length) console.log(`\nUI Bundles in ${project.uiBundlesDir}:\n${bundles.map((b, i) => `  ${i + 1}) ${b}`).join('\n')}`);
  const answer = await ask(bundles.length ? 'Bundle (number or name): ' : 'New UI Bundle name: ');
  const n = Number(answer);
  return Number.isInteger(n) && n >= 1 && n <= bundles.length ? bundles[n - 1] : answer;
}

async function resolveInputs(command, values, positionals) {
  if (positionals.length > 1) {
    const extra = positionals.slice(1).map((p) => JSON.stringify(p)).join(', ');
    throw new Error(
      `Unexpected argument(s): ${extra}. Only one source zip/folder is allowed. ` +
        'If you split the command over lines, each "\\" must be the last character on its line (or put it all on one line).'
    );
  }
  const project = loadProject(expandHome(values.project) || process.cwd());

  let source = expandHome(values.source || positionals[0]);
  if (!source && interactive()) source = expandHome(await ask('WaveMaker React code zip (or folder): '));
  if (!source) throw new Error('Pass the WaveMaker React code zip: wm-sf deploy <file.zip>');
  source = path.resolve(source.replace(/^['"]|['"]$/g, ''));
  if (!fs.existsSync(source)) throw new Error(`Source not found: ${source}`);

  const bundle = await chooseBundle(project, values.bundle);
  const bundleDir = resolveBundleDir(project, bundle);
  const bundleName = path.basename(bundleDir);
  validateBundleName(bundleName);

  const targetOrg = values['target-org'] || project.defaultOrg || null;
  if (command === 'deploy' && !targetOrg && !values['dry-run']) {
    throw new Error('No target org: pass --target-org <alias>, or run "sf config set target-org <alias>" in the project.');
  }

  return {
    command,
    project,
    source,
    bundleName,
    bundleDir,
    targetOrg,
    basePath: (values['base-path'] || `/app/${project.namespace || 'c'}__${bundleName}`).replace(/\/+$/, ''),
    workDir: path.resolve(expandHome(values['work-dir']) || path.join(project.root, '.wm-sf', bundleName)),
    buildCommand: values['build-command'] || 'npx next build',
    skipInstall: !!values['skip-install'],
    npmVerbose: !!values['npm-verbose'],
    skipExternalize: !!values['skip-externalize'],
    create: !!values.create,
    withApp: !!values['with-app'] || !!values.create,
    assignPermset: !!values['assign-permset'],
    extraDeployDirs: (values['deploy-dir'] || []).map((d) => path.resolve(expandHome(d))),
    wait: values.wait,
    dryRun: !!values['dry-run'],
    yes: !!values.yes
  };
}

function printPlan(o) {
  const rel = (p) => path.relative(process.cwd(), p) || '.';
  console.log(`
${log.bold('Plan')}
  Source       ${o.source}
  SFDX project ${o.project.root}${o.project.name ? log.dim(`  (${o.project.name})`) : ''}
  UI Bundle    ${o.bundleName}  ${log.dim(rel(o.bundleDir))}${fs.existsSync(o.bundleDir) ? '' : log.yellow('  (will be created)')}
  Base path    ${o.basePath}
  Work dir     ${o.workDir}
  Target org   ${o.command === 'deploy' ? o.targetOrg || log.dim('(sf default)') : log.dim('— build only —')}`);
}

async function confirm(o) {
  if (o.yes || !interactive()) return true;
  const answer = await ask(`\nProceed? ${log.dim('[Y/n]')} `);
  return answer === '' || /^y(es)?$/i.test(answer);
}

async function npmInstall(appDir, workDir, { skip, verbose }) {
  const hashFile = path.join(workDir, '.deps-hash');
  const hash = dependencyHash(appDir);
  const hasModules = fs.existsSync(path.join(appDir, 'node_modules'));
  if (skip) {
    if (!hasModules) log.warn('--skip-install, but there is no node_modules from an earlier run; the build will probably fail.');
    else log.ok('Skipped npm install (--skip-install)');
    return;
  }
  if (hasModules && fs.existsSync(hashFile) && fs.readFileSync(hashFile, 'utf8') === hash) {
    log.ok('Dependencies unchanged since the last run, reusing node_modules');
    return;
  }
  const args = ['install'];
  if (verbose) args.push('--verbose');
  await run('npm', args, { cwd: appDir });
  fs.writeFileSync(hashFile, hash);
  log.ok('npm install done');
}

async function cmdDeployOrBuild(command, values, positionals) {
  const o = await resolveInputs(command, values, positionals);
  printPlan(o);
  if (o.dryRun) {
    console.log(`\n${log.dim('Dry run: nothing was changed.')}`);
    return;
  }
  if (!(await confirm(o))) {
    console.log('Cancelled.');
    return;
  }
  if (command === 'deploy' && !(await hasCommand('sf'))) {
    throw new Error('Salesforce CLI ("sf") not found. Install it: npm install -g @salesforce/cli');
  }

  log.step('Check the UI Bundle');
  let permsetName = `${o.bundleName}_Access`;
  if (!fs.existsSync(path.join(o.bundleDir, 'ui-bundle.json'))) {
    if (!o.create) {
      throw new Error(
        `${o.bundleDir} is not a UI Bundle (no ui-bundle.json). Use --create, or run "wm-sf init ${o.bundleName}".`
      );
    }
    const res = scaffoldBundle(o.project, o.bundleName, {});
    res.created.forEach((f) => log.ok(`Created ${path.relative(o.project.root, f)}`));
    permsetName = res.permsetName;
  } else {
    log.ok(`${path.relative(o.project.root, o.bundleDir)}`);
  }
  const outDir = bundleOutputDir(o.bundleDir);

  log.step('Unpack the WaveMaker export');
  const appDir = prepareSource(o.source, o.workDir);
  log.ok(`${appDir}`);
  const gitignore = path.join(o.project.root, '.gitignore');
  if (o.workDir.startsWith(o.project.root + path.sep) && fs.existsSync(gitignore) && !/^\/?\.wm-sf\/?$/m.test(fs.readFileSync(gitignore, 'utf8'))) {
    log.warn(`Tip: add ".wm-sf/" to ${path.relative(process.cwd(), gitignore) || '.gitignore'} so the work folder isn't committed.`);
  }

  log.step('Install dependencies');
  await npmInstall(appDir, o.workDir, { skip: o.skipInstall, verbose: o.npmVerbose });

  log.step('Build for Salesforce');
  await buildBundle({ appDir, outDir, basePath: o.basePath, buildCommand: o.buildCommand, skipExternalize: o.skipExternalize });

  if (command === 'build') {
    console.log(`\n${log.green('Build ready.')} Deploy with:\n  sf project deploy start --source-dir ${path.relative(o.project.root, o.bundleDir)}${o.targetOrg ? ` --target-org ${o.targetOrg}` : ''}`);
    return;
  }

  log.step(`Deploy to ${o.targetOrg || 'the default org'}`);
  const base = path.join(o.project.packageDir, 'main', 'default');
  const sourceDirs = [o.bundleDir];
  if (o.withApp) {
    for (const f of [path.join(base, 'applications', `${o.bundleName}.app-meta.xml`), path.join(base, 'permissionsets', `${permsetName}.permissionset-meta.xml`)]) {
      if (fs.existsSync(f)) sourceDirs.push(f);
      else log.warn(`--with-app: ${path.relative(o.project.root, f)} not found, skipped`);
    }
  }
  sourceDirs.push(...o.extraDeployDirs);
  await deploy({ projectRoot: o.project.root, sourceDirs, targetOrg: o.targetOrg, wait: o.wait });
  log.ok('Deployed');

  if (o.assignPermset) {
    const status = await assignPermset({ projectRoot: o.project.root, permsetName, targetOrg: o.targetOrg });
    log.ok(`Permission set ${permsetName}: ${status}`);
  }

  const url = bundleUrl(await orgInstanceUrl({ projectRoot: o.project.root, targetOrg: o.targetOrg }), o.bundleName, o.project.namespace || 'c');
  console.log(`\n${log.green(log.bold('Done.'))}${url ? ` Open the app: ${url}` : ' Open the app from the App Launcher.'}`);
}

async function cmdInit(values, positionals) {
  const name = positionals[0] || values.bundle;
  if (!name) throw new Error('Usage: wm-sf init <bundle> [-p <project>]');
  const project = loadProject(expandHome(values.project) || process.cwd());
  const res = scaffoldBundle(project, validateBundleName(name), { label: values.label || name });
  if (!res.created.length) {
    console.log(`Nothing to do: ${name} already exists in ${project.root}.`);
    return;
  }
  res.created.forEach((f) => log.ok(`Created ${path.relative(project.root, f)}`));
  console.log(`\nNext: wm-sf deploy <export.zip> -p ${path.relative(process.cwd(), project.root) || '.'} -b ${name} --with-app --assign-permset`);
}

async function main(argv) {
  const { values, positionals } = parseArgs({ args: argv, options: OPTIONS, allowPositionals: true, strict: true });
  if (values.version) return console.log(pkg.version);

  const commands = ['deploy', 'build', 'init', 'help'];
  const command = commands.includes(positionals[0]) ? positionals.shift() : 'deploy';
  if (values.help || command === 'help' || (argv.length === 0 && !interactive())) return console.log(HELP);

  log.resetSteps();
  if (command === 'init') return cmdInit(values, positionals);
  return cmdDeployOrBuild(command, values, positionals);
}

module.exports = { main, HELP, resolveInputs };
