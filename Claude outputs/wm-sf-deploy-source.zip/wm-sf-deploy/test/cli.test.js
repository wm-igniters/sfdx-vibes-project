'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const AdmZip = require('adm-zip');

const { bundleUrl } = require('../src/deploy');
const { findAppRoot } = require('../src/source');
const { injectShim, shimSource } = require('../src/build');
const { scaffoldBundle } = require('../src/scaffold');
const { loadProject, listBundles } = require('../src/project');

const BIN = path.join(__dirname, '..', 'bin', 'wm-sf.js');

/** Fake `next build`: writes a tiny static export, BUILD_ID and the WaveMaker CSP helper. */
const FAKE_NEXT = `
const fs = require('fs'), path = require('path');
const base = process.env.NEXT_PUBLIC_BASE_PATH;
fs.mkdirSync('build/react-pages', { recursive: true });
fs.writeFileSync('build/index.html', '<!doctype html><html><head><title>x</title></head><body>' + base + '</body></html>');
fs.writeFileSync('build/react-pages/Main.html', '<html><head></head><body>main</body></html>');
fs.writeFileSync('build/react-pages/Main.txt', '0:rsc');
fs.mkdirSync('.next', { recursive: true });
fs.writeFileSync('.next/BUILD_ID', 'BUILD123\\n');
const helper = 'node_modules/@wavemaker-ai/react-codegen/src';
fs.mkdirSync(helper, { recursive: true });
fs.writeFileSync(helper + '/externalize-next-scripts.js',
  "exports.externalizeNextInlineScripts = (dir) => { require('fs').writeFileSync(dir + '/externalized.txt', 'yes'); return 2; };");
`;

/** Fake `sf`: logs its args and answers org display. */
const FAKE_SF = `#!/usr/bin/env node
const fs = require('fs');
fs.appendFileSync(process.env.SF_LOG, JSON.stringify({ cwd: process.cwd(), args: process.argv.slice(2) }) + '\\n');
if (process.argv[2] === '--version') { console.log('fake sf'); process.exit(0); }
if (process.argv[2] === 'org' && process.argv[3] === 'display') {
  console.log(JSON.stringify({ result: { instanceUrl: 'https://acme-dev-ed.develop.my.salesforce.com' } }));
}
`;

function setup({ withBundle = true } = {}) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-sf-'));
  // WaveMaker export zip (single top-level folder, as Studio downloads it)
  const appSrc = path.join(tmp, 'export', 'employeeapp-react');
  fs.mkdirSync(appSrc, { recursive: true });
  fs.writeFileSync(path.join(appSrc, 'package.json'), JSON.stringify({ name: 'wm-app', version: '1.0.0', private: true }));
  fs.writeFileSync(path.join(appSrc, 'fake-next.js'), FAKE_NEXT);
  const zipFile = path.join(tmp, 'employeeapp.zip');
  const zip = new AdmZip();
  zip.addLocalFolder(path.join(tmp, 'export'));
  zip.writeZip(zipFile);

  // SFDX project
  const project = path.join(tmp, 'sfdx');
  fs.mkdirSync(path.join(project, '.sf'), { recursive: true });
  fs.writeFileSync(path.join(project, 'sfdx-project.json'), JSON.stringify({ packageDirectories: [{ path: 'force-app', default: true }], name: 'demo' }));
  fs.writeFileSync(path.join(project, '.sf', 'config.json'), JSON.stringify({ 'target-org': 'Wavemaker' }));
  if (withBundle) {
    const b = path.join(project, 'force-app/main/default/uiBundles/employeeapp');
    fs.mkdirSync(path.join(b, 'dist'), { recursive: true });
    fs.writeFileSync(path.join(b, 'ui-bundle.json'), JSON.stringify({ outputDir: 'dist' }));
    fs.writeFileSync(path.join(b, 'dist', 'old.txt'), 'old build');
  }

  // fake sf on PATH
  const binDir = path.join(tmp, 'bin');
  fs.mkdirSync(binDir);
  fs.writeFileSync(path.join(binDir, 'sf'), FAKE_SF, { mode: 0o755 });
  const sfLog = path.join(tmp, 'sf.log');
  return { tmp, zipFile, project, binDir, sfLog };
}

function cli(env, args) {
  return spawnSync(process.execPath, [BIN, ...args], {
    encoding: 'utf8',
    env: { ...process.env, PATH: `${env.binDir}${path.delimiter}${process.env.PATH}`, SF_LOG: env.sfLog, NO_COLOR: '1', CI: '1' }
  });
}

const sfCalls = (env) => (fs.existsSync(env.sfLog) ? fs.readFileSync(env.sfLog, 'utf8').trim().split('\n').map(JSON.parse) : []);

test('deploy: unzips, installs, builds into the bundle and runs sf deploy', () => {
  const env = setup();
  const r = cli(env, ['deploy', env.zipFile, '-p', env.project, '--build-command', 'node fake-next.js', '-y']);
  assert.strictEqual(r.status, 0, r.stdout + r.stderr);

  const dist = path.join(env.project, 'force-app/main/default/uiBundles/employeeapp/dist');
  assert.ok(!fs.existsSync(path.join(dist, 'old.txt')), 'old build replaced');
  const index = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
  assert.match(index, /^<!doctype html><html><head><script src="\/app\/c__employeeapp\/sf-shim\.js\?v=BUILD123"><\/script>/);
  assert.match(index, /\/app\/c__employeeapp<\/body>/, 'base path passed to the build');
  assert.ok(fs.existsSync(path.join(dist, 'react-pages/Main.txt.json')));
  assert.ok(fs.existsSync(path.join(dist, 'externalized.txt')), 'CSP helper ran');
  assert.match(fs.readFileSync(path.join(dist, 'sf-shim.js'), 'utf8'), /"BUILD123"/);

  const deployCall = sfCalls(env).find((c) => c.args[0] === 'project');
  assert.deepStrictEqual(deployCall.args, [
    'project', 'deploy', 'start',
    '--source-dir', path.join('force-app', 'main', 'default', 'uiBundles', 'employeeapp'),
    '--target-org', 'Wavemaker'
  ]);
  assert.strictEqual(fs.realpathSync(deployCall.cwd), fs.realpathSync(env.project));
  assert.match(r.stdout, /https:\/\/acme-dev-ed--c\.develop\.my\.salesforce\.app\/app\/c__employeeapp/);
});

test('second run reuses node_modules when dependencies are unchanged', () => {
  const env = setup();
  const args = ['build', env.zipFile, '-p', env.project, '--build-command', 'node fake-next.js', '-y'];
  assert.strictEqual(cli(env, args).status, 0);
  const second = cli(env, args);
  assert.strictEqual(second.status, 0, second.stderr);
  assert.match(second.stdout, /Dependencies unchanged since the last run/);
});

test('build: does not call sf deploy', () => {
  const env = setup();
  const r = cli(env, ['build', env.zipFile, '-p', env.project, '--build-command', 'node fake-next.js', '-y']);
  assert.strictEqual(r.status, 0, r.stderr);
  assert.ok(!sfCalls(env).some((c) => c.args[0] === 'project'));
  assert.match(r.stdout, /Build ready/);
});

test('missing bundle fails with a hint, --create scaffolds and deploys app + permset', () => {
  const env = setup({ withBundle: false });
  const fail = cli(env, ['deploy', env.zipFile, '-p', env.project, '-b', 'newapp', '--build-command', 'node fake-next.js', '-y']);
  assert.strictEqual(fail.status, 1);
  assert.match(fail.stderr, /--create|wm-sf init newapp/);

  const ok = cli(env, ['deploy', env.zipFile, '-p', env.project, '-b', 'newapp', '--create', '--assign-permset', '--build-command', 'node fake-next.js', '-y']);
  assert.strictEqual(ok.status, 0, ok.stdout + ok.stderr);
  const base = path.join(env.project, 'force-app/main/default');
  assert.ok(fs.existsSync(path.join(base, 'uiBundles/newapp/newapp.uibundle-meta.xml')));
  assert.match(fs.readFileSync(path.join(base, 'applications/newapp.app-meta.xml'), 'utf8'), /<uiBundle>c__newapp<\/uiBundle>/);
  const deployArgs = sfCalls(env).find((c) => c.args[0] === 'project').args.join(' ');
  assert.match(deployArgs, /uiBundles[\\/]newapp/);
  assert.match(deployArgs, /applications[\\/]newapp\.app-meta\.xml/);
  assert.match(deployArgs, /permissionsets[\\/]newapp_Access\.permissionset-meta\.xml/);
  assert.ok(sfCalls(env).some((c) => c.args.slice(0, 3).join(' ') === 'org assign permset' && c.args.includes('newapp_Access')));
});

test('stray arguments (e.g. a broken line continuation) are rejected', () => {
  const env = setup();
  const r = cli(env, ['deploy', env.zipFile, ' --project', env.project, '--dry-run']);
  assert.strictEqual(r.status, 1);
  assert.match(r.stderr, /Unexpected argument\(s\): " --project"/);
});

test('dry run changes nothing', () => {
  const env = setup();
  const r = cli(env, ['deploy', env.zipFile, '-p', env.project, '--dry-run']);
  assert.strictEqual(r.status, 0, r.stderr);
  assert.match(r.stdout, /Dry run/);
  assert.ok(fs.existsSync(path.join(env.project, 'force-app/main/default/uiBundles/employeeapp/dist/old.txt')));
  assert.strictEqual(sfCalls(env).length, 0);
});

test('several bundles need --bundle when not interactive', () => {
  const env = setup();
  fs.mkdirSync(path.join(env.project, 'force-app/main/default/uiBundles/other'), { recursive: true });
  fs.writeFileSync(path.join(env.project, 'force-app/main/default/uiBundles/other/ui-bundle.json'), '{}');
  const r = cli(env, ['deploy', env.zipFile, '-p', env.project, '--dry-run']);
  assert.strictEqual(r.status, 1);
  assert.match(r.stderr, /Several UI Bundles found \(employeeapp, other\)/);
});

test('init scaffolds bundle, app and permission set once', () => {
  const env = setup({ withBundle: false });
  const project = loadProject(env.project);
  const first = scaffoldBundle(project, 'illustrationapp', {});
  assert.strictEqual(first.created.length, 4);
  assert.deepStrictEqual(listBundles(project), ['illustrationapp']);
  assert.strictEqual(scaffoldBundle(project, 'illustrationapp', {}).created.length, 0);
  assert.throws(() => scaffoldBundle(project, 'bad-name', {}), /not a valid UI Bundle name/);
});

test('bundleUrl derives the salesforce.app URL from the My Domain', () => {
  assert.strictEqual(bundleUrl('https://acme.my.salesforce.com', 'employeeapp'), 'https://acme--c.my.salesforce.app/app/c__employeeapp');
  assert.strictEqual(
    bundleUrl('https://orgfarm-9e9d6b0a8b-dev-ed.develop.my.salesforce.com', 'employeeapp'),
    'https://orgfarm-9e9d6b0a8b-dev-ed--c.develop.my.salesforce.app/app/c__employeeapp'
  );
  assert.strictEqual(bundleUrl('https://example.com', 'x'), null);
  assert.strictEqual(bundleUrl(null, 'x'), null);
});

test('findAppRoot unwraps a single top-level folder and ignores __MACOSX', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-root-'));
  fs.mkdirSync(path.join(dir, 'app'));
  fs.mkdirSync(path.join(dir, '__MACOSX'));
  fs.writeFileSync(path.join(dir, 'app', 'package.json'), '{}');
  assert.strictEqual(findAppRoot(dir), path.join(dir, 'app'));
});

test('shim is valid JavaScript and injection is idempotent', () => {
  assert.doesNotThrow(() => new Function(shimSource('B1')));
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-shim-'));
  fs.writeFileSync(path.join(dir, 'a.html'), '<html><head></head></html>');
  assert.strictEqual(injectShim(dir, '/app/c__x', 'B1'), 1);
  assert.strictEqual(injectShim(dir, '/app/c__x', 'B1'), 0);
});
