# wm-sf-deploy

Build a **WaveMaker React** code export as a **Salesforce UI Bundle** (Multi-Framework app) and deploy it to an org — one command instead of unzip → copy script → `npm i` → build → `sf project deploy start`.

```bash
wm-sf deploy ~/Downloads/employeeapp.zip \
  --project ~/Documents/WM-SF/my-sfdx-vibes-project \
  --bundle employeeapp \
  --target-org Wavemaker
```

## Install

```bash
npm install -g ./wm-sf-deploy-0.1.0.tgz   # from the packed file
# or, from this folder while developing:
npm install && npm link
```

Requires Node.js 18.3+, npm, and the Salesforce CLI (`sf`) logged in to the target org (`sf org login web --alias Wavemaker`).

## Inputs

| Input | Flag | Default |
|---|---|---|
| WaveMaker React code zip (or extracted folder) | `[source]` or `-s, --source` | asked for in a terminal |
| Salesforce DX project | `-p, --project` | current folder (or the nearest parent with `sfdx-project.json`) |
| UI Bundle (Multi-Framework app) | `-b, --bundle <name or path>` | the only bundle under `<package>/main/default/uiBundles` |
| Target org | `-o, --target-org` | the project's `target-org` (`sf config set target-org …`) |

In a terminal, anything missing is asked for and the plan is shown for confirmation (`-y` skips it). In CI, pass everything as flags.

## Commands

```bash
wm-sf deploy [source] [options]   # unzip → npm install → build → copy into the bundle → sf deploy
wm-sf build  [source] [options]   # same, without the deploy
wm-sf init   <bundle> [-p dir]    # new UI Bundle + Custom Application + <bundle>_Access permission set
```

### Options

| Option | What it does |
|---|---|
| `--base-path <path>` | URL base path baked into the build (default `/app/c__<bundle>`) |
| `--work-dir <dir>` | Where the export is unpacked and built (default `<project>/.wm-sf/<bundle>`; add `.wm-sf/` to `.gitignore`) |
| `--build-command <cmd>` | Next.js build command (default `npx next build`) |
| `--skip-install` / `--npm-verbose` | Skip `npm install` / run it with `--verbose` |
| `--skip-externalize` | Skip moving Next's inline scripts out for CSP |
| `--create` | Create the bundle, app and permission set if the bundle doesn't exist (and deploy them) |
| `--with-app` | Also deploy the bundle's Custom Application and permission set |
| `--assign-permset` | Assign `<bundle>_Access` to the deploying user |
| `--deploy-dir <path>` | Extra metadata to deploy in the same request (repeatable) |
| `--wait <min>` | Passed to `sf project deploy start --wait` |
| `--dry-run` | Print the plan and stop |
| `-y, --yes` | No confirmation prompt |

## What the build does

Same steps as `scripts/build-sf-bundle.js` (the shim it writes is byte-for-byte identical), without copying a script into every export:

1. `next build` with `NEXT_PUBLIC_BASE_PATH` / `NEXT_PUBLIC_SERVER_PATH` = the base path.
2. Moves Next's inline scripts out (WaveMaker's `externalize-next-scripts`), for the UI Bundle CSP.
3. Copies RSC payloads `*.txt` → `*.txt.json` (Salesforce serves `.txt` as HTML).
4. Writes `sf-shim.js` (RSC fetch rewrite, `?v=<buildId>` cache-busting, deep-link reset, servicedefs) and loads it first in every page.
5. Replaces the bundle's output folder (`ui-bundle.json` → `outputDir`, default `dist`).

`node_modules` is kept in the work folder between runs; `npm install` is skipped when `package.json` / `package-lock.json` haven't changed.

## First deploy of a new app

```bash
wm-sf init illustrationapp -p ./my-sfdx-vibes-project
wm-sf deploy ~/Downloads/illustrationapp.zip -p ./my-sfdx-vibes-project -b illustrationapp --with-app --assign-permset
```

## Programmatic use

```js
const { buildBundle, loadProject } = require('wm-sf-deploy');
```
